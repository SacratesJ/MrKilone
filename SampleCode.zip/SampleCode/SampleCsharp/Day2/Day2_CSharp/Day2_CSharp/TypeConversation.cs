﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_CSharp
{
    class TypeConversation
    {
        static void Main()
        {

            Console.WriteLine("New Main");

            double str = 52.0f;
            int i;
            i = (int)str;
            Console.WriteLine(i);

            string str2 = "Te3st";
            for (i = 0; i < str2.Length; i++)
            {
                if (char.IsDigit(str2[i]))
                    Console.WriteLine(str2[i]);
            }

            Console.WriteLine("\\constant");
            Console.WriteLine("\\\\constant");
            Console.WriteLine("Test\tKey");
            //Console.WriteLine("{0}\robestbuddy", str2);
            //string teststr = str2 + "\rbuddy";
            //Console.WriteLine(teststr);
            Console.WriteLine(typeof(TypeConversation));


            int exp1=1, exp2=2, exp3=3;
            var res = exp1==1 ? exp2 : exp3;
            Console.WriteLine(res);
            Console.ReadLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Day2_CSharp
{
    class MultiThread :ThreadSample
    {
        static void Main(string [] args)
        {
            
            ThreadSample objThreadClass = new ThreadSample();
            Thread threadObj = new Thread(new ThreadStart(objThreadClass.SimpleThread));
            threadObj.Start();
            Thread.Sleep(10000);
            Console.ReadLine();
            



        }
    }

    public class ThreadSample
    {
        

        public void SimpleThread()
        {
            for (int i = 0; i <= 5; i++)
            {
                Console.WriteLine("My Thread  - {0}",i );
            }
        }

         protected static void CallingStaticMethod()
        {
            Console.WriteLine("Static Method Called");
        }
    }
}

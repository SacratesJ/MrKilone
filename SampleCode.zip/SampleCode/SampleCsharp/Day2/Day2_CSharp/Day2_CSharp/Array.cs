﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_CSharp
{
    class Array
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Argument length: " + args.Length);
            Console.WriteLine("Supplied Arguments are:");
            foreach (Object obj in args)
            {
                Console.WriteLine(obj);
                Console.WriteLine("\n");

            }

            int[] array1 = new int[1];
            array1[0] = 1;
            int i = 0;
            for ( i = 0; i < array1.Length; i++)
            {
                Console.WriteLine(array1[i]);
                Console.WriteLine("\n");
            }
            
            assignParams(1,2,3,4,5);
           
            Console.ReadKey();


        }
        static void assignParams(params int[] val)
        {
            int i;
            for (i = 0; i < val.Length; i++)
            {
                Console.WriteLine(val[i]);
            }
        }
    }
}

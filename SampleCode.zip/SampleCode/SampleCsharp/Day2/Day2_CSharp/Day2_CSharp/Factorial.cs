﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_CSharp
{
    class Factorial
    {
        static void Main()
        {
            Console.WriteLine("Enter the Factorial Number");

            int entrNumber = int.Parse(Console.ReadLine());

            int fact = 1;
            for (int i = 1; i <= entrNumber; i++)
            {
                fact = fact * i;
            }

            Console.WriteLine("Factorial Value is : {0} ",fact);
            Console.ReadLine();
          

        }
    }
}

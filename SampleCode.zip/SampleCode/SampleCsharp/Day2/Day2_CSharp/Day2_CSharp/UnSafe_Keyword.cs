﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_CSharp
{
    class UnSafe_Keyword
    {
         static unsafe void Main(string[] args)
        {
            UnSafe_Keyword point = new UnSafe_Keyword();
            double[] arr = { 0, 1.5, 2.3, 3.4, 4.0, 5.9 };
            string str = "Hello World";

            // The following two assignments are equivalent. Each assigns the address 
            // of the first element in array arr to pointer p. 

            // You can initialize a pointer by using an array. 

            fixed (double* p = arr) { /*...*/ }
            

            Unsafe();
            Console.ReadKey();
        }
        public static unsafe void Unsafe()
        {
            int var = 20;
            int* p = &var;
            Console.WriteLine("Data is: {0} ", var);
            Console.WriteLine("Data is: {0} ", p->ToString());
            Console.WriteLine("Address is: {0} ", (int)p);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_CSharp
{
    public class UsingKeyword
    {
        static void Main(string[] args)
        {
            Console.Title = "Use of using Keyword";

            #region Case - I  
            //Using_Keyword ms1 = new Using_Keyword();
            //try
            //{
            //    ms1.DoSomeTask();
            //}
            //catch(Exception)
            //{
            //    Console.WriteLine("error");
            //}
            //finally
            //{
            //   // ms1.Dispose();
            //}
            #region Case - II  
            using (Using_Keyword ms = new Using_Keyword())
            {
                ms.DoSomeTask();
            }
            #endregion
            #endregion
            Console.ReadLine();
        }

    }
    public class Using_Keyword : IDisposable
    {
        public void Dispose()
        {
            Console.WriteLine("Releasing all the resources......");
        }
        public void DoSomeTask()
        {
            Console.WriteLine("Starting some task......");
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Doing some task.....");
            }
        }
    }

}

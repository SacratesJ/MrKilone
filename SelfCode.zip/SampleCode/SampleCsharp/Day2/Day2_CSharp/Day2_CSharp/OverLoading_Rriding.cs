﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_CSharp
{
    public class OverLoading_Rriding
    {
        static void Main(string[] args)
        {
            SecondClass _obj_SecodClass = new SecondClass();
            _obj_SecodClass.Method_Show();
            _obj_SecodClass.Method1(0);            

            

            Console.ReadKey();
        }
        
    }
    public class PrivateClass
    {
        private PrivateClass()
        {
            Console.WriteLine("Private");
        }
    }
    public class FirstClass
    {
        public virtual string Method_Show()
        {
            Console.WriteLine("Base Class Virtual Method");
            return null;
        }
        public virtual int  Method1(int a)
        {
            Console.WriteLine("Base Class");
            return 0;
        }
    }
    public class SecondClass : FirstClass
    {
        public new int Method_Show()
        {
            Console.WriteLine("Sub Class Override Method");
            return 0;
        }        
        public override int Method1(int a)
        {
            Console.WriteLine("sub2 Class");
            return 0;
        }
    }
    
}

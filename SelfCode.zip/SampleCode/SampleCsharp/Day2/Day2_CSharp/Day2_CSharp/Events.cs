﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_CSharp
{
    public  delegate string del_handelerlist();
    class Events
    {
        public event del_handelerlist addEvent;
        static void Main()
        {
            Events obj = new Events();
            obj.addEvent += new del_handelerlist(obj.USA);
            obj.addEvent += new del_handelerlist(obj.India);
            obj.addEvent += new del_handelerlist(obj.England);
            obj.addEvent.Invoke();
            Console.ReadLine();                       
        }
        public string  USA()
        {
            Console.WriteLine("USA");
            return null;
        }

        public string India()
        {
            Console.WriteLine("India");
            return null;
        }

        public  string  England()
        {
            Console.WriteLine("England");
            return null;
        }
    }
}

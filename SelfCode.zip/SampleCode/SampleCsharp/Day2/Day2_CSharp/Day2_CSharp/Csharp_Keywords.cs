﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Day2_CSharp
{
    public class Csharp_Keywords 
    {
        readonly int b = 1;
        static int d;
        public Csharp_Keywords()
        {
            b = 35;
            Console.WriteLine("\nRead only Value :{0}", b);
        }
        static void Main(string[] args)
        {
            Csharp_Keywords _obj_MainMethodClass = new Csharp_Keywords();
            #region Keyword "byte" and "Char"
            // This data type of byte length will be 0 to 255
            // single or array of byte we can create but the length of Max value is 255

            //byte byt = 255;
            byte[] bytarray = { 0, 255 };

            //char singleletteronly = 'a';
            char[] arrayletteronly = { 'a', 'b' };
            #endregion

            #region Checked and unchecked
            int chkint = int.MaxValue;
            //chkint = checked(chkint + 1); //Airthmetic Overflow error will be occure
            chkint = unchecked(chkint + 1);
            Console.WriteLine("\n" + chkint);
            #endregion

            #region Const,ReadOnly,static

            const int a = 5; //Once int a value assigned we cannot re-assign the values
            const int c = 6;
            Console.WriteLine("\nConst value : {0}****{1}", a, c);

            d = 4555;
            Console.WriteLine("\nstatic only value :{0}", d);
            Console.WriteLine("\nread only value :{0}", _obj_MainMethodClass.b);
            #endregion

            #region Decimal Keyword
            decimal maxdecimalnum = decimal.MaxValue;
            Console.WriteLine("\nDecimal Max Value is :{0}", maxdecimalnum);
            #endregion


            #region Access Modifier

            #region Private  Access Modifier
            // we will try to call from another Class
            // 1-- Class created with Private not able to create the obj in same namespace code is below
            // error occured in compile time
            /*
             Severity	Code	Description	Project	File	Line	Suppression State
            Error	CS1527	Elements defined in a namespace cannot be explicitly declared as private, protected, protected internal, or private protected	
            Day2_CSharp	Z:\Sakradeesh\SampleCode\SampleCsharp\Day2\Day2_CSharp\Day2_CSharp\Csharp_Keywords.cs	65	Active

             */
            UnderstandThe_PrivateAccessModifier _obj_PrivateAccess = new UnderstandThe_PrivateAccessModifier();
            
            //In the above class craeted the Private datamember and Method 
            // Not able to access both by using the ObjPrivateAccess Object

            // !!!!!!! If Private Constructor then we can't create the object for any class. 



            #endregion
            #region Protected Access Modifier
            // We can't create the Class with Protected Access Modifier
            // From the Prarent or Super Class of Object not able to access the Protected DataMember and Member
            UnderstandingThe_ProtectedAccessModifier _obj_ProtectedAccess = new UnderstandingThe_ProtectedAccessModifier();
            ///**********************************
            //_obj_ProtectedAccess.publicMethod();
            //_obj_MainMethodClass.ProtectedMethod();
            //!!!!! But able to access the Protected DataMember and Member from Object of SubClass of Object

            //Console.WriteLine("\nProtected data value from Parent Class with Protected Access Modifier datamember :{0}", objMainMethodClass.protecetedintDataMember);
            //objMainMethodClass.ProtectedMethod();

            #endregion
            #region Protected Internal Access Modifier
            // We can't create the class name with Protected Internal Access Modifier

            //We can access dataMember and Member Function by using class of Object and also from SubClass of Object as well.
            UnderstandingThe_ProtectedInternalAccessModifier _obj_protinternal = new UnderstandingThe_ProtectedInternalAccessModifier();
            Console.WriteLine("\nAble to access DataMember from the class of Object : {0}", _obj_protinternal.protInternalNum);
            Console.WriteLine("*** able to call the Protected Internal Method by using the class of Object*****************");
            _obj_protinternal.ProtInternalMethod();


            #endregion
            #region Private Protected Access Modifier
            // we cann't access the DataMember and Member fuction from class of Object
            UnderstandingThe_PrivateProtectedAccessModifier _obj_privateProtected = new UnderstandingThe_PrivateProtectedAccessModifier();

            // But we can access the DataMember and MemberFunction from Subclass of Object
            //objMainMethodClass.private_ProtectedMethod();
            #endregion
            #region Internal Access Modifier
            // Able the create the object with Internal Access Modifier 
            UnderstandingThe_InternalAccessModifier _obj_InternalAccess = new UnderstandingThe_InternalAccessModifier();
            //Able to access the DataMember and Member of Fuction by using the class of Object.
            Console.WriteLine("\nInternal DataMember Value is : {0}", _obj_InternalAccess.internal_Data);
            _obj_InternalAccess.Internal_Method();
            _obj_InternalAccess.Virtual_VoidMethod();

            #endregion

            #endregion
            #region MyRegion

            #region Sealed Class descriptions
            // We can't derived to Super sealed class to sub class
            /*
             Severity	Code	Description	Project	File	Line	Suppression State
            Error	CS0509	'Csharp_Keywords': cannot derive from sealed type 'Sealed_Class'	
            Day2_CSharp	Z:\Sakradeesh\SampleCode\SampleCsharp\Day2\Day2_CSharp\Day2_CSharp\Csharp_Keywords.cs	9	Active

             */

            // 
            Sealed_Class _obj_Sealed_Class = new Sealed_Class();
            // we can't create the Abstract or Virtual Method in sealed Class
            _obj_Sealed_Class.Sealed_Class_Method();
            #endregion
            #region Static Class
            // able to create the static class
            //But not able to create the object of Static  class
            //below error occurred 
            /*
             Severity	Code	Description	Project	File	Line	Suppression State
            Error	CS0723	Cannot declare a variable of static type 'Static_Class'	
            Day2_CSharp	Z:\Sakradeesh\SampleCode\SampleCsharp\Day2\Day2_CSharp\Day2_CSharp\Csharp_Keywords.cs	136	Active

             */
            //Static_Class _obj_staticClass = new Static_Class();

            // If need to call the Datamember of Member of function from Static Class its should be public
            // becuase by default it's private access
            Static_Class.StaticClass_Method();


            #endregion
            #region Struct it's Similar like Class but storing the value like value Type
            Struct_Keyword _obj_Struct = new Struct_Keyword();
            _obj_Struct.Struct_Method();
            _obj_Struct.struct_num = 15;
            Console.WriteLine("The Struct number value : {0}", _obj_Struct.struct_num);
            Struct_Keyword _obj_Struct2 = _obj_Struct;
            _obj_Struct2.struct_num = 25;
            // The _obj_Struct.struct_num value is not updated but if we use the normal class then value will be update.
            Console.WriteLine("The Struct number value : {0}", _obj_Struct.struct_num);
            #endregion
            #region Abstract Class
            // we cannot create the object or instance for Abstract Class
            //_obj_MainMethodClass.Abstract_Method();

            // So we are using the another sub class  for accessing it 
            calling_Abstracut_Class _obj_CallingAbstractClass = new calling_Abstracut_Class();
            _obj_CallingAbstractClass.virtualMethod();
            _obj_CallingAbstractClass.absMethod();

            #endregion
            #region Interface class
            Calling_InterfaceClass _obj_Interfaceone = new Calling_InterfaceClass();
            Interface_Class_One _obj_interface_Class_One = new Calling_InterfaceClass();
            _obj_interface_Class_One.One_InterfaceMethod();
            Interface_Class_Two _obj_interface_Class_Two = new Calling_InterfaceClass();
            _obj_interface_Class_Two.One_InterfaceMethod();
            #endregion

            #endregion

            #region Ref Keyword
            int ref_num=250;
            WithoutRefUpdate(ref_num);
            Console.WriteLine("\nValue Type (Integer) without called the Ref value is : {0}", ref_num);
            WithRefUpdate(ref ref_num);
            Console.WriteLine("\nValue Type (Integer) with called ref value is : {0}", ref_num);

            #endregion

            #region OutKeyword
            int out_num=12;
            WitOutUpdate(out out_num);
            Console.WriteLine("\nWithout assigned the values we use OUT Keyword : {0}",out_num);
            #endregion
            #region Extern Keyword 

            //MessageBox(0, "Extern Keyowrd", "My Message Box", 0);

            #endregion
            #region fixed Keyword

            int fxInt = 27;
            
            #endregion

            Console.ReadLine();
        }
        [DllImport("User32.dll")]
        public static extern int MessageBox(int h, string m, string c, int type);

        public static void WithoutRefUpdate(int ref_num)
        {
            ref_num = 300;
        }
        public static void WithRefUpdate(ref int ref_num)
        {
            ref_num = 300;
        }

        public static void WitOutUpdate(out int out_num)
        {
            out_num = 88;
        }
       

    }
    
    public class Calling_InterfaceClass : Interface_Class_One, Interface_Class_Two
    {
        //public void One_InterfaceMethod()
        //{
        //    Console.WriteLine("\nTest interface same name if Method..");

        //}
        public int interface_num_one { get; set; }
        void Interface_Class_One.One_InterfaceMethod()
        {
            Console.WriteLine("\n1st Interface same name if Method..");

        }
        void Interface_Class_Two.One_InterfaceMethod()
        {
            Console.WriteLine("\n2nd Interface same name if Method..");

        }
    }
    interface Interface_Class_One
    {
       int interface_num_one { get; set; }
        void One_InterfaceMethod();

    }
    interface Interface_Class_Two
    {
        void One_InterfaceMethod();

    }
    public class calling_Abstracut_Class : Abstract_Class
    {
        public override void absMethod()
        {
            Console.WriteLine("\nOnly implementation in the Sub class");
        }
        public override void virtualMethod()
        {
            base.virtualMethod();
            Console.WriteLine("\nVirtual Method in Sub Class...");
        }
    }
    public abstract class Abstract_Class
    {
        public abstract void absMethod();
        public void Abstract_Method()
        {
            Console.WriteLine("\nAbstract Class Method Calling ....");
        }
        public virtual void virtualMethod()
        {
            Console.WriteLine("\nVirtual Method in Abstract Class...");
        }
    }
    public struct Struct_Keyword
    {
        public int struct_num;
        public void Struct_Method()
        {
            Console.WriteLine("\nMethod calling from the Structure");
        }
    }

    static class Static_Class
    {
        public static int Static_data = 45;
        public static void StaticClass_Method()
        {
            Console.WriteLine("Public Method from Static Class...");
        }
    }
    sealed class Sealed_Class
    {
        public void Sealed_Class_Method()
        {
            Console.WriteLine("\nThe Method from Sealed Class..");
        }
    }

    internal class UnderstandingThe_InternalAccessModifier
    {
        internal int internal_Data = 56;
        internal void Internal_Method()
        {
            Console.WriteLine("Internal Method calling ....");
        }
        public virtual void Virtual_VoidMethod()
        {
            Console.WriteLine("Virtual method calling ...");
        }
    }
    public class UnderstandingThe_PrivateProtectedAccessModifier
    {
        private protected int private_protecetedintDataMember = 23;
        private protected void private_ProtectedMethod()
        {
            Console.WriteLine("Private_Protected Method from class..");
        }
    }
    public class UnderstandingThe_ProtectedInternalAccessModifier
    {
        protected internal int protInternalNum = 56;
        protected internal void ProtInternalMethod()
        {
            Console.WriteLine("Protected Internal Method Calling");
        }
    }
    public class UnderstandingThe_ProtectedAccessModifier
    {

        protected int protecetedintDataMember = 23;
        protected void ProtectedMethod()
        {
            Console.WriteLine("Protected Method from class..");
        }
        public void publicMethod()
        {
            Console.WriteLine("Protected Method from class..");
        }


    }
    public class UnderstandThe_PrivateAccessModifier
    {
        private static int staticPrivatevalue = 33;
        public UnderstandThe_PrivateAccessModifier()
        {
            Console.WriteLine("\nPrivate Datamember from Constructor " + "Value is {0 }", a + staticPrivatevalue);
            Console.WriteLine("***************************");
            Console.WriteLine("Calling the Consturtor Private Memmber method.");
            PrivateMethod();
        }

        private int a = 2231;
        private void PrivateMethod()
        {
            Console.WriteLine("Private Method from class");
        }


    }
}

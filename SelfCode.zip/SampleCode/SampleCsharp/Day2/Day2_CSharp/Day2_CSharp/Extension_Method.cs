﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_CSharp
{
    class Extension_Method
    {
        static void Main(string[] args)
        {
            Student student = new Student();
            Console.WriteLine(student.GetName());
            Console.WriteLine(student.GetUpperName());
            int result=0;
            int res =student.name.FindthestringCount(result);
            Console.WriteLine(res);
            Console.ReadLine();
        }

       
    }
  
    public static class StudentHelper
    {
        public static string GetUpperName(this Student student) // Using this before Student class  
        {
            return student.name.ToLower();
        }
        public static int FindthestringCount(this string str,int result)
        {
            //int result = 0;
            foreach (char item in str)
            {
                if (item.ToString() != "")
                    result = result + 1;
            }
            return result;
        }
    }
    public class Student
    {
        public string name = "JAvatpoint254645454";
        public string GetName()
        {
            return this.name.ToUpper();
        }

    }
}

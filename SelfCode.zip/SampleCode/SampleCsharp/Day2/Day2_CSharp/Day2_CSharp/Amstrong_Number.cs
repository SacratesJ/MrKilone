﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_CSharp
{
    class Amstrong_Number
    {
        static void Main()
        {
            Console.WriteLine("Enter the Amstong number");
            int entrnum = int.Parse(Console.ReadLine());
            int keepernumber = entrnum, result = 0,sum=0;
            Console.WriteLine("***********************");
            while(entrnum>0)
            {

                result = entrnum % 10;
                sum = sum  + (result * result * result);
                entrnum = entrnum / 10;
            }
            if(keepernumber==sum)
            Console.WriteLine("Number result is : {0}",sum);
            else
                Console.WriteLine("Not Number result is : {0}", sum);
            Console.ReadLine();
        }
    }
}

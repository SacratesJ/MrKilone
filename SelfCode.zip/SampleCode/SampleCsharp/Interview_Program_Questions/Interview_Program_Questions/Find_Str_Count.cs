﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interview_Program_Questions
{
    public class Find_Str_Count
    {
        static void Main(string[] args)
        {
            string str = "countby countby count code";
            Dictionary<char, int> findCountChar = new Dictionary<char, int>();
            foreach (var charFromLst in str)
            {
                if(charFromLst != ' ')
                {
                    if(!(findCountChar.ContainsKey(charFromLst)))
                    {
                        findCountChar.Add(charFromLst, 1);
                    }
                    else
                    {
                        findCountChar[charFromLst] = findCountChar[charFromLst] + 1;
                    }
                }
            }
            Console.WriteLine("The Finding results in below");
            foreach (var item in findCountChar )
            {
                Console.WriteLine("\n {0} -{1}",item.Key,item.Value);
            }
            str = "abcd";
            StringBuilder subString = null;
            for (int i = 0; i < str.Length; ++i)
            {
                 subString = new StringBuilder(str.Length - i);
                for (int j = i; j < str.Length; ++j)
                {
                    subString.Append(str[j]);
                    Console.Write(subString + " ");
                }
            }
            str = null;
            for (int i = 0; i < subString.Length; i++)
            {
                for ( int j = 0; j < subString.Length; j++)
                {
                    str = str + subString[j];
                    Console.WriteLine("Test");
                    Console.WriteLine("\n", str);
                }

            }
            
            Console.ReadLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interview_Program_Questions
{
   public class Reverse_String_Order
    {
        static void Main(string[] args)
        {
            string str = null;
            int i;
            StringBuilder reverseSentence = new StringBuilder();

            int Start = str.Length - 1;
            int End = str.Length - 1;

            while (Start > 0)
            {
                if (str[Start] == ' ')
                {
                    i = Start + 1;
                    while (i <= End)
                    {
                        reverseSentence.Append(str[i]);
                        i++;
                    }
                    reverseSentence.Append(' ');
                    End = Start - 1;
                }
                Start--;
            }

            for (i = 0; i <= End; i++)
            {
                reverseSentence.Append(str[i]);
            }
            Console.WriteLine(reverseSentence.ToString());





            // Start = reverseSentence.Length - 1;
            // End = reverseSentence.Length - 1;

            //string str_reverseSentence = null;
            //while (Start > 0)
            //{
            //    if (reverseSentence[Start] == ' ')
            //    {
            //        i = Start + 1;
            //        while (i <= End)
            //        {
            //            str_reverseSentence = str_reverseSentence + reverseSentence[i];
            //            i++;
            //        }
            //        str_reverseSentence = str_reverseSentence + ' ';
            //        End = Start - 1;
            //    }
            //    Start--;
            //}

            //for (i = 0; i <= End; i++)
            //{
            //    str_reverseSentence = str_reverseSentence + reverseSentence[i];
            //}
            //Console.WriteLine(str_reverseSentence.ToString());

            Console.ReadKey();
        }
    }
}

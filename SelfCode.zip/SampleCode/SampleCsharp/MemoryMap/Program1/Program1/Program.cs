﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.MemoryMappedFiles;

namespace Program1
{
    class Program
    {
        static void Main(string[] args)
        {

            // create a memory-mapped file of length 1000 bytes and give it a 'map name' of 'test'  
            MemoryMappedFile mmf = MemoryMappedFile.CreateNew("test", 1000);
            MemoryMappedFile nmmf = MemoryMappedFile.CreateOrOpen("Createopen", 1000);
            // write an integer value of 42 to this file at position 500  
            MemoryMappedViewAccessor naccess = nmmf.CreateViewAccessor();
            naccess.Write(300, 30);
            MemoryMappedViewAccessor accessor = mmf.CreateViewAccessor();
            accessor.Write(500, 42);
            Console.WriteLine("Memory-mapped file created!");
            Console.ReadLine(); // pause till enter key is pressed  
                                // dispose of the memory-mapped file object and its accessor  
            accessor.Dispose();
            mmf.Dispose();

        }
    }
}


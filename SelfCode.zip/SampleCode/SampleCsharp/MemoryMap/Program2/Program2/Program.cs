﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.MemoryMappedFiles;

namespace Program2
{
    class Program
    {
        static void Main(string[] args)
        {
            MemoryMappedFile mmf = MemoryMappedFile.OpenExisting("test");
            // read the integer value at position 500  
            MemoryMappedViewAccessor accessor = mmf.CreateViewAccessor();
            int value = accessor.ReadInt32(500);
            // print it to the console  
            Console.WriteLine("The answer is {0}", value);

            MemoryMappedFile nmmf = MemoryMappedFile.OpenExisting("Createopen");
            MemoryMappedViewAccessor naccess = nmmf.CreateViewAccessor();
            int res = naccess.ReadInt32(300);
            Console.WriteLine("The Second Answer is {0} ",res);
            // dispose of the memory-mapped file object and its accessor  
            accessor.Dispose();
            mmf.Dispose();
            Console.ReadLine();
        }
    }
}

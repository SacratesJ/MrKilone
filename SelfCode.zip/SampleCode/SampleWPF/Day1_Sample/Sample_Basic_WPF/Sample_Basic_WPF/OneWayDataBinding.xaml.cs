﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Sample_Basic_WPF
{
    /// <summary>
    /// Interaction logic for OneWayDataBinding.xaml
    /// </summary>
    public partial class OneWayDataBinding : Window
    {
        Person objPerson = new Person { Name = "Jack", Age = 25 };
        public OneWayDataBinding()
        {
            InitializeComponent();
            this.DataContext = objPerson;
        }

        private void btnShow_Click(object sender, RoutedEventArgs e)
        {
            string message = objPerson.Name + " is " + objPerson.Age;
            MessageBox.Show(message);
        }
    }
    public class Person
    {
        public string nameValue;
        
        public string Name {
            get { return nameValue; }
            set { nameValue=value; }
        }

        public double ageValue;
        public double Age
        {
            get { return ageValue; }
            set { ageValue = value; }
        }
    }
}

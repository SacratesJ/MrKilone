﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using MVVM_SampleWPF.Model;

namespace MVVM_SampleWPF.ViewModel
{
    public class StudentViewModel
    {
        public IMyCommand DeleteCommand { get; set; }

        public StudentViewModel()
        {
            this.LoadStudents();
            DeleteCommand = new IMyCommand(OnDelete, CanDelete);
        }
        public ObservableCollection<Student> Students { get; set; }

        public void LoadStudents()
        {
            ObservableCollection<Student> students = new ObservableCollection<Student>();
            students.Add(new Student { FirstName = "Mark", LastName = "_LastMark" });
            students.Add(new Student { FirstName = "Dom", LastName = "_LastDom" });
            students.Add(new Student { FirstName = "Tim", LastName = "_LastTim" });
            students.Add(new Student { FirstName = "Hendry", LastName = "_LastHendry" });

            Students = students;
        }
        private Student _selectedStudent;
        public Student SelectedStudent
        {

            get { return _selectedStudent; }
            set
            {
                _selectedStudent = value;
                DeleteCommand.RaisedCanExecuteChanged();
            }
        }
        private void OnDelete()
        {
            Students.Remove(_selectedStudent);
        }
        private bool CanDelete()
        {
            return _selectedStudent != null;
        }


    }
}

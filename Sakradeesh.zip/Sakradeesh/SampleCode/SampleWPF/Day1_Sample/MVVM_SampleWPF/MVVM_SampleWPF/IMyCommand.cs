﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace MVVM_SampleWPF
{
    public class IMyCommand : ICommand
    {
        Action _TargetExecutedMethod;
        Func<bool> _TargetCanExecuteMethod;

        public IMyCommand(Action executeMethod)
        {
            _TargetExecutedMethod = executeMethod;
        }

        public IMyCommand(Action executeMethod, Func<bool> canExecuteMethod)
        {
            _TargetExecutedMethod = executeMethod;
            _TargetCanExecuteMethod = canExecuteMethod;
        }

        public void RaisedCanExecuteChanged()
        {

            CanExecuteChanged(this, EventArgs.Empty);
        }
        #region Icommand Interface Implemendation
        public event EventHandler CanExecuteChanged = delegate { };
        void ICommand.Execute(object parameter)
        {
            if (_TargetExecutedMethod != null)
            {
                _TargetExecutedMethod();
            }
        }
        bool ICommand.CanExecute(object parameter)
        {
            if (_TargetCanExecuteMethod != null)
            {
                return _TargetCanExecuteMethod();
            }
            if (_TargetExecutedMethod != null)
            { return true; }
            return false;
        }

        #endregion
    }
}

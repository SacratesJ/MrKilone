﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_CSharp
{
    class PalindromeNumber
    {
        static void Main()
        {
            Console.WriteLine("Enter the nunmber find the Palindrome");

            int entrnum = int.Parse(Console.ReadLine());
            int numkeeper = entrnum, result, sum = 0;

            Console.WriteLine("***********");
            while (entrnum>0)
            {
                result = entrnum % 10;
                sum = (sum * 10) + result;
                entrnum = entrnum / 10;
            }

            if(sum==numkeeper)
                Console.WriteLine("Entered number is {0} Palindrome", sum);
            else
                Console.WriteLine("Entered number is not {0} Palindrome", sum);


            Console.ReadLine();
        }
    }
}

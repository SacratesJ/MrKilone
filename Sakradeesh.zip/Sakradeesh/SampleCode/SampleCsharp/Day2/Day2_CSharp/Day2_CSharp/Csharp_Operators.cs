﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_CSharp
{
    public class Csharp_Operators 
    {
        static int stint = 10;

        static void Main(String[] args)
        {
            int uniory = 3, shiftnum = 2;
            //uniory++;
            //uniory--;


            int number = 20;

            Console.WriteLine("{0}<<1 = {1}", number, number << 1);
            Console.WriteLine("{0}<<2 = {1}", number, number << 2);
            Console.WriteLine("{0}<<3 = {1}", number, number << 3);
            Console.WriteLine("{0}<<4 = {1}", number, number << 4);


            Console.WriteLine("***************************");
            Console.WriteLine("{0}>>1 = {1}", number, number >> 1);
            Console.WriteLine("{0}>>2 = {1}", number, number >> 2);
            Console.WriteLine("{0}>>3 = {1}", number, number >> 3);
            Console.WriteLine("{0}>>4 = {1}", number, number >> 4);


            string str = null;
            var res = str ?? "string values is empty";

            int one = 2, two = 2; bool result;
            result = two == one ? true : false;
            Console.WriteLine(result);


            int assint = 9;
            assint = assint ^ 3;
            Console.WriteLine(assint);
            Console.WriteLine("***************");
            byte[] bnum = { 255, 255 };
            Console.WriteLine(bnum[0]);
            char[] cstr = { 'a', 'b' };
            int a = 2147483647;
            var chkres = checked(a);
            Console.WriteLine("*****  checked :  {0}", chkres);
            chkres = unchecked(a + 1);
            Console.WriteLine("*****  checked :  {0}", chkres);
            ReadOnlyClass readOnlyClass = new ReadOnlyClass();            
            readOnlyClass.print();
            stint = 12;
            Console.WriteLine("**** {0}",stint);


            for (int i = 0; i < 10; i++)
            {
                if (i == 4)
                {
                    Console.WriteLine(i);
                    break;
                    
                }
                Console.WriteLine(i);
            }

            Console.ReadLine();
        }

    }
    public class ReadOnlyClass
    {
        public static int rdint = 5;
        
        public ReadOnlyClass()
        {
            rdint = 8;
        }
    public void print()
    {
            rdint = 10;
        Console.WriteLine("************ {0}", rdint);

    }
}
}

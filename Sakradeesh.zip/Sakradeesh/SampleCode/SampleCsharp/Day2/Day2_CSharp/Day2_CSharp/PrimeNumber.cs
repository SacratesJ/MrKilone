﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_CSharp
{
    class PrimeNumber
    {
        static void Main()
        {
            Console.WriteLine("Enter the number for finding the Prime or Not");
            int enumber = int.Parse(Console.ReadLine());
            int firstDivide = 0, flag = 0;

            firstDivide = enumber / 2;

            for (int i = 2; i <= firstDivide; i++)
            {
                if (enumber % i == 0)
                {
                    Console.WriteLine("It's not Prime number");
                    flag = 1;
                    break;
                }
            }
            if (flag == 0)
            {
                Console.WriteLine("Its Prime number");
            }

            Console.ReadLine();
        }
    }
}

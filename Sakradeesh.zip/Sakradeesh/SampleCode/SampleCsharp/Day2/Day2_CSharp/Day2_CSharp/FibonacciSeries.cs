﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_CSharp
{
    class FibonacciSeries
    {
        static void Main(string[] args) 
        {
            Console.WriteLine("Enter you number for FibancciSeries :");
            int lengthnumber=int.Parse(Console.ReadLine());
            int zero = 0, one = 1, result;
            Console.WriteLine("The results of {0} number fibonacci series ",lengthnumber);


            Console.WriteLine(zero+"",one+"");
            for (int i = 2; i < lengthnumber; i++)
            {
                result = zero + one;
                Console.WriteLine(result +"");
                zero = one;
                one = result;
            }

            Console.ReadLine();
        
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interview_Program_Questions
{
    class String_Palindrome
    {
       static void Main(string[] args)
        {

            string str = "book";            
            int i = 0, j = 0;
            bool flag=false;            
            for (i = str.Length -1; j < str.Length / 2; i--,j++)
            {
                if (str[i] != str[j])
                {
                    flag = false;
                    break;
                }
                else
                    flag = true;   
            }

            if(flag)
                Console.WriteLine("Palindrome");
            else
                Console.WriteLine("Not Palindrome");

            Console.ReadKey();
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interview_Program_Questions
{
    class FindMaxnumbers_Array
    {
        static void Main(string[] args)
        {
            int[] Test_Array = { 0, 3, 4, -2, 8, 5,10 };
            int large_number = 0;
            int second_number = 0;
            int n_number = 0;
            #region 1st Way using soriting and for each loop
            Array.Sort(Test_Array);
            Console.WriteLine("Sorted Array asscending order \n");
            foreach (var item in Test_Array)
            {
                if(item>large_number)
                {
                    second_number = large_number;
                    large_number = item;
                }
              
                Console.WriteLine(item);
            }
            Console.WriteLine("*****************\n");
            Console.WriteLine(second_number);
            Console.WriteLine("*******************\n");
            Console.WriteLine("\nSorted desceding Order of array");
            Array.Reverse(Test_Array);
            foreach (var item in Test_Array)
            {
                Console.WriteLine(item);
            }
            #endregion
            #region 2ND Using the Orderby and Skip and First default
            int[] nd2_Test_Array = { 0, 3, 4, -2, 8, 5, 10 };
            int second_int = (from number in nd2_Test_Array
                              orderby number descending
                              select number).Distinct().Skip(2).First();

            Console.WriteLine("*************\n");
            Console.WriteLine("2nd logic  : {0} ",second_int);
            #endregion
            Console.WriteLine("\n********************");

            int[] myArray = new int[] { 0, 3, 4, -2, 8, 5, 10 };
            int Smallest = myArray.Min();
            int Largest = myArray.Max();
            foreach (int i in myArray)
            {
                if (i > Smallest && i < Largest)
                {
                    Smallest = i;
                }
            }
            System.Console.WriteLine(Smallest);

            Console.ReadLine();
        }
    }
}

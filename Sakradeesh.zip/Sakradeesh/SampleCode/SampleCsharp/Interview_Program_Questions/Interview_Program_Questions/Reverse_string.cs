﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interview_Program_Questions
{
    public class Reverse_string
    {
        static void Main(string[] args) {

            string str = "em tel";
            char[] revStrchar = str.ToCharArray();
            int i=0,j=0;
            for (j = str.Length-1;  i<j ; j--,i++)
            {
                revStrchar[i] = str[j];
                revStrchar[j] = str[i];
            }            
            Console.WriteLine(revStrchar);
            Console.ReadLine();
        }
    }
}

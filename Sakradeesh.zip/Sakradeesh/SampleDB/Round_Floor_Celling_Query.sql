declare @temp1 table(idone decimal(10,2))
declare @temp2 table(idtwo decimal(10,2))
insert into @temp1 values(11.25),(2.65),(5.89)
insert into @temp2 values(1),(3),(2)

select idone,ROUND(idone,5,0),FLOOR(idone) as rvalue,CEILING(idone) from @temp1







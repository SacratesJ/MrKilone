USE Sample_Test
GO
DROP TABLE IF EXISTS #TEMP1
DROP TABLE IF EXISTS #TEMP2
GO
CREATE table #temp1 (idone int not null,idtwo int not null,idthree int)



create clustered index lrn_Indexwith_Temp_Clusterd on #temp1 (idone)
create nonclustered index lrn_Indexwith_Temp_Clusterd1 on #temp1 (idone)
create nonclustered index lrn_Indexwith_Temp_Clusterd2 on #temp1 (idone)

ALTER TABLE #temp1 ADD constraint test PRIMARY KEY (idone);

CREATE table #temp2 (idtwo int not null,idtone int not null foreign key references #temp1(idone))
--ALTER TABLE #temp2 ADD constraint temp2_PrimeKey PRIMARY KEY (idtwo);



insert into #temp1 values (1,2,3)
insert into #temp1 values (2,2,null)
insert into #temp1 values (3,3,null)

--insert into #temp2 values (1,null)
--insert into #temp2 values (2,null)



SELECT * FROM #temp1

EXECUTE TEMPDB.dbo.SP_HELPINDEX '#TEMP1'
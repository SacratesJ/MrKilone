declare @temp1 table(idone int)
declare @temp2 table(idtwo int)
insert into @temp1 values(1),(1),(2)
insert into @temp2 values(1),(1),(3)
--select * from @temp1
--select * from @temp2

select *,'InnerJoin' as JoinName from @temp1 t1 
inner join @temp2 t2 on t1.idone=t2.idtwo

select *,'full join' as JoinName  from @temp1 t1 
full join @temp2 t2 on t1.idone=t2.idtwo

select *,'LeftJoin' as JoinName from @temp1 t1 
left join @temp2 t2 on t1.idone=t2.idtwo
select *,'LeftOuterJoin' as JoinName from @temp1 t1 
left outer join @temp2 t2 on t1.idone=t2.idtwo
select *,'rightJoin' as JoinName from @temp1 t1 
right join @temp2 t2 on t1.idone=t2.idtwo
select *,'rightouterJoin' as JoinName from @temp1 t1 
right outer join @temp2 t2 on t1.idone=t2.idtwo

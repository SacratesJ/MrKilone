declare @temp1 table(idone int)
declare @temp2 table(idtwo int)
insert into @temp1 values(1),(1),(2)
insert into @temp2 values(1),(1),(3)

select * from @temp1
union 
select * from @temp2

select * from @temp1
union all
select * from @temp2

select * from @temp1
intersect
select * from @temp2

select * from @temp1
except
select * from @temp2
select * from @temp1
except
select * from @temp2

